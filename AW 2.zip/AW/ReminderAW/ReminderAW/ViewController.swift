//
//  ViewController.swift
//  ReminderAW
//
//  Created by R.M.K. Engineering College on 25/03/17.
//  Copyright © 2017 RMKEC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

   
    @IBOutlet weak var textField: UITextField!

    @IBAction func addTaskButton(_ sender: Any) {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let task = Task(context: context)
        task.name = textField.text!
        (UIApplication.shared .delegate as! AppDelegate).saveContext()
        dismiss(animated: true,completion: nil)
        
    }
}

