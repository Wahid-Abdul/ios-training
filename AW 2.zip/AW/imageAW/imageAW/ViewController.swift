//
//  ViewController.swift
//  imageAW
//
//  Created by R.M.K. Engineering College on 24/03/17.
//  Copyright © 2017 RMKEC. All rights reserved.
//

import UIKit

class ViewController : UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    @IBAction func pickImage(_ sender: UIButton) {
        present(imagePicker,animated: true,completion: nil)
    }
    
    @IBOutlet weak var pickedImage: UIImageView!
    var imagePicker : UIImagePickerController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        imagePicker = UIImagePickerController()
        imagePicker.sourceType = .photoLibrary
        pickedImage.contentMode = .scaleAspectFit
        imagePicker.delegate = self
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]){
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage{
            pickedImage.image = image
            dismiss(animated:true,completion:nil)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    

}

