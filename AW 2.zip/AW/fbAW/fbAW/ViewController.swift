//
//  ViewController.swift
//  fbAW
//
//  Created by R.M.K. Engineering College on 25/03/17.
//  Copyright © 2017 RMKEC. All rights reserved.
//

import UIKit
import Social

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func fbPost(_ sender: Any) {
        if SLComposeViewController.isAvailable(forServiceType: SLServiceTypeFacebook){
            let fbPost = SLComposeViewController(forServiceType: SLServiceTypeFacebook)
            
            fbPost?.setInitialText("This is a post")
            
            self.present(fbPost!,animated: true,completion:nil)
            
        }
        else{
            print("Sorry...!!")
        }
        
    }

}

