//
//  ViewController.swift
//  fetchAW
//
//  Created by R.M.K. Engineering College on 25/03/17.
//  Copyright © 2017 RMKEC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let urlString  = "http://www.mocky.io/v2/58d60ca8100000ad14d0b26d"
        
        loadDataFrom(urlString : urlString )
        {
            ( responseDict ) in
            
            let studentInfo:[[String:Any]] = (responseDict!["studentInfo"] as? [[String:Any]])!
            
            for students:[Sting:Any] in studentInfo{
                print(students["name"])
            }
        }
        
    }
    func loadDataFrom(url :URL,completion: @escaping ([String:Any]?)->()){
        
        let config = URLSessionConfiguration.default
        
        let session = URLSession(configuration: config)
        
        let urlString  = "http://www.mocky.io/v2/58d60ca8100000ad14d0b26d"
        let url = URL(string: urlString)
        
        let task = session.dataTask(with:url!){
            
            (data,response,error) in
        
        guard error == nil else{
            return
        }
        
        if let data = data{
            
            do{
            let jsonDict = try JSONSerialization.jsonObject(with:data,options:JSONSerialization.ReadingOptions.mutableContainers) as? [String:Any]
            
            completion(jsonDict)
            }
        catch {
                print(error)
            }
        }
    }
    task.resume()
    }
    //task.resume()
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

