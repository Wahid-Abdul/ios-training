//
//  ViewController.swift
//  Phase2Day1FF
//
//  Created by R.M.K. Engineering College on 24/03/17.
//  Copyright © 2017 RMKEC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var rails: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func segementControl(_ sender: UISegmentedControl) {
        let selectTitle = sender.titleForSegment(at: sender.selectedSegmentIndex)! as String
        switch selectTitle {
        case "fill":
            rails.contentMode = .scaleAspectFill
        case "fit":
            rails.contentMode = .scaleAspectFit
        default:
            rails.contentMode = .scaleToFill
       
        }
        
    }
}

