//
//  ViewController.swift
//  demoAW
//
//  Created by R.M.K. Engineering College on 24/03/17.
//  Copyright © 2017 RMKEC. All rights reserved.
//

import UIKit


class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    
    
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    
    //myActivityIndicator.view = view.center
    
    
   
    
    
    // If needed, you can prevent Acivity Indicator from hiding when stopAnimating() is called
    //myActivityIndicator.hidesWhenStopped = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    
    @IBAction func loadImage(_ sender: Any) {
        
        var img: UIImage!
        
         self.activityIndicator.startAnimating()
        
        DispatchQueue.global(qos: .background).async {
            // Background Thread
            
            

             let imgURL = URL(string:"https://www.apple.com/v/apple-watch-series-2/c/images/overview/hero_large.jpg")
            
            do {
                let imgData = try Data(contentsOf: imgURL!)
                img = UIImage(data: imgData)
                    
                    
                    DispatchQueue.main.async {
                        
                        self.imageView.image = img
                        
                        self.activityIndicator.stopAnimating()
                        
                        // Run UI Updates
                    }
                
            } catch { print (error)
            }
            
           
        }
        
        
//         activityIndicator.startAnimating()
//        
//        
//        let imgURL = URL(string:"https://www.apple.com/v/apple-watch-series-2/c/images/overview/hero_large.jpg")
//        do
//        {
////            let activityView = UIActivityIndicatorView(activityIndicatorStyle: .whiteLarge)
////            activityView.center = self.view.center
////            activityView.startAnimating()
////            
////            self.view.addSubview(activityView)
//            
//           
//            
//            let imgData = try Data(contentsOf: imgURL!)
//            let image = UIImage(data:imgData)
//            imageView.image = image
//            activityIndicator.stopAnimating()
//        }
//            
//        catch
//        {
//            print(error)
//            
//        }
        
    
    
    }

}
